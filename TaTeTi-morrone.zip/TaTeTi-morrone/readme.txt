Este ejercicio lo realicé con clases. No sabia bien donde aplicar bootstrap asi que le puse un navBar para poder
utilizar algun componente con esa dependencia.
Por otro lado, me trabé bastante en la función de "calcularGanador" así que busqué en la web y encontré una que,
luego de entenderla, ya no me la podía sacar de la cabeza. Todo lo que se me ocurría era mas complicado y 
no tan práctico por lo que implementé la que encontré, sinceramente me pareció la más simple y también me tentó porque 
no es tanto de React sino más bien de JS esa funcionalidad.
Quedo atenta a observaciones :)

Dependencias utilizadas:
react-bootstrap bootstrap@4.1.1


Sls!

Flor.
